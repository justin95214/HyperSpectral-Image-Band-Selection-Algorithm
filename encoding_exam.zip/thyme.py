#-*-coding:utf-8 -*-

"""
 Created by Wonseok Jung in KETI on 2021-03-16.
"""

import conf
import http_app

conf = conf.conf

resp_mqtt_ri_arr = []

resp_mqtt_path_arr = {}
socket_q = {}

sh_state = 'crtae'

mqtt_client = None

if __name__ == '__main__':
    # while True:
    http_app.http_watchdog()