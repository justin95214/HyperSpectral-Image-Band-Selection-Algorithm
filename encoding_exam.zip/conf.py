# -*-coding:utf-8 -*-

"""
 Created by Wonseok Jung in KETI on 2021-03-16.
"""

import socket
import uuid

conf = {}
cse = {}
ae = {}
cnt_arr = []
sub_arr = []
acp = {}

conf["useprotocol"] = 'http'  # select one for 'http' or 'mqtt' or 'coap' or 'ws'

# build cse
cse["host"] = '203.253.128.177'
cse["port"] = '7579'
cse["name"] = 'Mobius'
cse["id"] = '/Mobius2'
cse["mqttport"] = '1883'
cse["wsport"] = '7577'

# build ae
ae_name = {}

ae["name"] = "Wonseok"

ae["id"] = 'S' + ae["name"]

ae["parent"] = '/' + cse["name"]
ae["appid"] = str(uuid.uuid1())
ae["port"] = '9727'
ae["bodytype"] = 'json'  # select 'json' or 'xml' or 'cbor
ae["tas_mav_port"] = '3105'
ae["tas_sec_port"] = '3105'

# build cnt
count = 0
container = {}
container['parent'] = '/' + cse['name'] + '/' + ae['name']
container["name"] = "Encoding"
cnt_arr.append(container)

# container = {}
# container['parent'] = '/' + cse['name'] + '/' + ae['name']
# container["name"] = "tvoc"
# cnt_arr.append(container)
#
# container = {}
# container['parent'] = '/' + cse['name'] + '/' + ae['name']
# container["name"] = "co2"
# cnt_arr.append(container)
#
# container = {}
# container['parent'] = '/' + cse['name'] + '/' + ae['name']
# container["name"] = "temp"
# cnt_arr.append(container)
#
# container = {}
# container['parent'] = '/' + cse['name'] + '/' + ae['name']
# container["name"] = "led"
# cnt_arr.append(container)


# build sub
my_ip = socket.gethostbyname(socket.getfqdn())
subscribe = {}
subscribe['parent'] = '/' + cse["name"] + '/' + ae["name"] + '/' + cnt_arr[0]["name"]
subscribe["name"] = 'sub-image'
subscribe["nu"] = 'http://' + my_ip + ':' + ae["port"] + '/noti?ct=json'  # http
# subscribe["nu"] = 'mqtt://' + cse["host"] + '/' + ae["id"] + '?ct=' + ae["bodytype"]  # mqtt
sub_arr.append(subscribe)


# build acp: not complete
acp["parent"] = '/' + cse["name"] + '/' + ae["name"]
acp["name"] = 'acp-' + ae["name"]
acp["id"] = ae["id"]

conf["usesecure"] = 'disable'

if conf["usesecure"] == 'enable':
    cse["mqttport"] = '8883'

conf["cse"] = cse
conf["ae"] = ae
conf["cnt"] = cnt_arr
conf["sub"] = sub_arr
conf["acp"] = acp
