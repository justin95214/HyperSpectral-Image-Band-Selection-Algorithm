# -*-coding:utf-8 -*-

"""
 Created by Wonseok Jung in KETI on 2021-03-16.
"""

import uuid

import threading
from functools import wraps

import thyme
import conf
import thyme_tas
import http_adn

HTTP_SUBSCRIPTION_ENABLE = 0
MQTT_SUBSCRIPTION_ENABLE = 0


def delay(delay=0.):
    """
    Decorator delaying the execution of a function for a while.
    """

    def wrap(f):
        @wraps(f)
        def delayed(*args, **kwargs):
            timer = threading.Timer(delay, f, args=args, kwargs=kwargs)
            timer.start()

        return delayed

    return wrap


class Timer():
    toClearTimer = False

    def setTimeout(self, fn, time):
        isInvokationCancelled = False

        @delay(time)
        def some_fn():
            if (self.toClearTimer is False):
                fn()
            else:
                print('Invokation is cleared!')

        some_fn()
        return isInvokationCancelled

    def setClearTimer(self):
        self.toClearTimer = True


timer = Timer()


def getType(p):
    type = 'string'
    if isinstance(p, list):
        type = 'list'
    elif isinstance(p, str):
        try:
            if isinstance(p, dict):
                type = 'string_dictionary'
            else:
                type = 'string'
        except Exception as e:
            type = 'string'
            return type
    elif (p is not None) and (isinstance(p, dict)):
        type = 'dictionary'
    else:
        type = 'other'
    return type


return_count = 0
request_count = 0


def ae_response_action(status, res_body):
    aeid = res_body['m2m:ae']['aei']
    conf.conf['ae']['id'] = aeid

    return status, aeid


def create_cnt_all(count):
    if len(conf.conf['cnt']) == 0:
        return 2001, count
    else:
        try:
            if conf.conf['cnt'][count] is not None:
                parent = conf.conf['cnt'][count]['parent']
                rn = conf.conf['cnt'][count]['name']
                rsc, res_body, count = http_adn.crtct(parent, rn, count)
                if rsc == 5106 or rsc == 2001 or rsc == 4105:
                    count += 1
                    status, count = create_cnt_all(count)
                    return status, count
                else:
                    return 9999, count
            else:
                return 2001, count
        except Exception as e:
            # print(e)
            return 2001, count


def delete_sub_all(count):
    if len(conf.conf['sub']) == 0:
        return 2001, count
    else:
        if len(conf.conf['sub']) > count:
            target = conf.conf['sub'][count]['parent'] + '/' + conf.conf['sub'][count]['name']
            rsc, res_body, count = http_adn.delsub(target, count)
            if rsc == 5106 or rsc == 2002 or rsc == 2000 or rsc == 4105 or rsc == 4004:
                count += 1
                status, count = delete_sub_all(count)
                return status, count
            else:
                return 9999, count
        else:
            return 2001, count


def create_sub_all(count):
    if len(conf.conf['sub']) == 0:
        return 2001, count
    else:
        if len(conf.conf['sub']) > count:
            parent = conf.conf['sub'][count]['parent']
            rn = conf.conf['sub'][count]['name']
            nu = conf.conf['sub'][count]['nu']
            rsc, res_body, count = http_adn.crtsub(parent, rn, nu, count)
            if rsc == 5106 or rsc == 2001 or rsc == 4105:
                count += 1
                status, count = create_sub_all(count)
                return status, count
            else:
                return '9999', count
        else:
            return 2001, count


drone_info = {}
mission_parent = []


def http_watchdog():
    global return_count
    global request_count

    print('[sh_state] : {}'.format(thyme.sh_state))

    if thyme.sh_state == 'crtae':
        print('[sh_state] : {}'.format(thyme.sh_state))
        status, res_body = http_adn.crtae(conf.conf['ae']['parent'], conf.conf['ae']['name'], conf.conf['ae']['appid'])
        print(res_body)
        if status == 2001:
            status, aeid = ae_response_action(status, res_body)
            print('x-m2m-rsc : ' + str(status) + ' - ' + aeid + ' <----')
            thyme.sh_state = 'rtvae'
            request_count = 0
            return_count = 0

            http_watchdog()
        elif status == 5106 or status == 4105:
            print('x-m2m-rsc : ' + str(status) + ' <----')
            thyme.sh_state = 'rtvae'

            http_watchdog()
        else:
            print('x-m2m-rsc : ' + str(status) + ' <----')
            http_watchdog()
    elif thyme.sh_state == 'rtvae':
        if conf.conf['ae']['id'] == 'S':
            conf.conf['ae']['id'] = 'S' + uuid.uuid1()

        print('[sh_state] : {}'.format(thyme.sh_state))
        status, res_body = http_adn.rtvae(conf.conf['ae']['parent'] + '/' + conf.conf['ae']['name'])
        if status == 2000:
            aeid = res_body['m2m:ae']['aei']
            print('x-m2m-rsc : ' + str(status) + ' - ' + aeid + ' <----')

            if (conf.conf['ae']['id'] != aeid) and (conf.conf['ae']['id'] != ('/' + aeid)):
                print('AE-ID created is ' + aeid + ' not equal to device AE-ID is ' + conf.conf['ae']['id'])
            else:
                thyme.sh_state = 'crtct'
                request_count = 0
                return_count = 0

                http_watchdog()
        else:
            print('x-m2m-rsc : ' + str(status) + ' <----')
            http_watchdog()
    elif thyme.sh_state == 'crtct':
        print('[sh_state] : {}'.format(thyme.sh_state))
        status, count = create_cnt_all(request_count)
        if status == 9999:
            http_watchdog()
        else:
            count += 1
            request_count = count
            return_count = 0
            if len(conf.conf['cnt']) <= count:
                thyme.sh_state = 'delsub'
                request_count = 0
                return_count = 0

                http_watchdog()
    elif thyme.sh_state == 'delsub':
        print('[sh_state] : {}'.format(thyme.sh_state))
        status, count = delete_sub_all(request_count)
        if status == 9999:
            http_watchdog()
        else:
            count += 1
            request_count = count
            return_count = 0
            if len(conf.conf['sub']) <= count:
                thyme.sh_state = 'crtsub'
                request_count = 0
                return_count = 0

                http_watchdog()
    elif thyme.sh_state == 'crtsub':
        print('[sh_state] : {}'.format(thyme.sh_state))
        status, count = create_sub_all(request_count)
        if status == 9999:
            print('[???} create container error!')
        else:
            count += 1
            request_count = count
            return_count = 0
            if len(conf.conf['sub']) <= count:
                thyme.sh_state = 'crtci'

                thyme_tas.main()

                http_watchdog()
    elif thyme.sh_state == 'crtci':
        pass
        # print('[sh_state] : {}'.format(thyme.sh_state))
        # if conf.sim == 'enable':
        #     period = 1000
        #     cnt_idx = 0


def send_to_Mobius(topic, content_each_obj, gap):
    http_adn.crtci(topic + '?rcn=0', 0, content_each_obj, None)
