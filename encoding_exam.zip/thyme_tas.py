import cv2
import socket, json
import base64
import conf
import datetime
import http_adn
import http_app


def base64_encode(image):
    encode = base64.b64encode(image[1])
    return encode


aggr_content = {}


def send_aggr_to_Mobius(topic, content_each, gap):
    if aggr_content.get(topic):
        timestamp = datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%S%f')[:-3]
        aggr_content[topic][timestamp] = content_each

    else:
        aggr_content[topic] = {}
        timestamp = datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%S%f')[:-3]
        aggr_content[topic][timestamp] = content_each

        def upload():
            http_adn.crtci(topic + '?rcn=0', 0, aggr_content[topic], None)
            del aggr_content[topic]

            return gap, topic

        http_app.timer.setTimeout(upload, gap)


def main():

    cap = cv2.VideoCapture(0)
    frameWidth = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frameHeight = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    frame_size = (frameWidth, frameHeight)

    frameRate = 33
    count = 0
    c = 1
    while True:
        retval, frame = cap.read()
        if not (retval):
            break

        cv2.imshow('frame', frame)
        key = cv2.waitKey(frameRate)


        if key == 27:
            break

        image = './image/{}.jpg'.format(count)
        cv2.imwrite(image, frame)

        if (count % 30) == 0:
            encode = base64_encode(frame)
            http_adn.crtci(conf.conf['cnt'][0]['parent'] + '/' + conf.conf['cnt'][0]['name'] + '?rcn=0', 0, encode.decode('utf-8'), None)
        count += 1

    if cap.isOpened():
        cap.release()

    cv2.destroyAllWindows()
